Darkest Dungeon II — Arabic translation
Translation and localization: Abdullah Hadi
============================================================

What is this?
A complete, unofficial Arabic translation of the text of Darkest Dungeon II on Steam: the base game, the Catacombs
and Dul Cru DLCs, and Kingdoms mode. Text is drawn right-to-left with joined letters; the voices stay in English.

Install
1. Close the game.
2. Copy the "Darkest Dungeon II_Data" folder from here into the game folder and agree to replace the files.
   Steam: right-click the game > Manage > Browse local files.
3. Start the game, then Options > Game > Language: choose «العربية».

Notes
- Made for the Steam game build 24911282. After a game update, part of it may stop working until a new
  version of the translation is released.
- Steam "Verify integrity of game files" restores two original files and partly disables the translation.
  Copy the folder again afterwards.
- Two game files are replaced:
   Darkest Dungeon II_Data\Managed\IronCrown.dll
   Darkest Dungeon II_Data\Managed\Unity.TextMeshPro.dll
  Every other file is new and sits next to the game's own files.

Uninstall
1. Steam: right-click the game > Properties > Installed Files > Verify integrity of game files.
2. Delete these files and folders from the game folder:
   Darkest Dungeon II_Data\Managed\DD2Arabic.dll
   Darkest Dungeon II_Data\StreamingAssets\Arabic\
   Darkest Dungeon II_Data\StreamingAssets\Localization\Poedit\ar.po
   Darkest Dungeon II_Data\StreamingAssets\Localization\Poedit\arabic_language\
   Darkest Dungeon II_Data\StreamingAssets\Localization\Poedit\dlc_catacombs\ar.po
   Darkest Dungeon II_Data\StreamingAssets\Localization\Poedit\dlc_dul_cru\ar.po
   Darkest Dungeon II_Data\StreamingAssets\Localization\Poedit\game_type_override_kingdom\ar.po
   Darkest Dungeon II_Data\StreamingAssets\Localization\Sources\arabic_language\

Fonts: Almarai and Aref Ruqaa, SIL Open Font License (Darkest Dungeon II_Data\StreamingAssets\Arabic\OFL*.txt).

Unofficial fan translation, not affiliated with the developer or the publisher.
